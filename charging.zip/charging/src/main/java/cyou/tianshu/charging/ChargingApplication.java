package cyou.tianshu.charging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChargingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChargingApplication.class, args);
	}

}
