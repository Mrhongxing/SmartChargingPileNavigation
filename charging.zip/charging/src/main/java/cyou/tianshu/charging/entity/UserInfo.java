package cyou.tianshu.charging.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * 用户信息
 *
 * 说明：
 * - 你原来代码里 Mapper/SQL 使用的表是 smart_charging_user（含 id 字段）
 * - 这里把实体统一为 smart_charging_user，避免“表名/主键不一致”导致查不到数据
 *
 * 如果你数据库真实表名不是 smart_charging_user，请把 @TableName 改成真实表名，
 * 同时确保主键字段名称与 @TableId(value="...") 一致。
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@TableName("smart_charging_user")
public class UserInfo {

    @TableId(value = "id", type = IdType.AUTO)
    private Long id; // 主键

    @TableField("name")
    private String name;

    @TableField("email")
    private String email;

    @TableField("password")
    private String password;

    @TableField("role")
    private String role;

    @TableField("created_at")
    private LocalDateTime createdAt;

    @TableField("updated_at")
    private LocalDateTime updatedAt;

    @TableField("phone")
    private String phone;

    @TableField("car_type")
    private String carType;

    @TableField("car_brand")
    private String carBrand;

    // 兼容你原来的注册逻辑：邮箱注册时把 email 写入，同时 name 先留空
    public UserInfo(String emailOrName, String password) {
        if (emailOrName != null && emailOrName.contains("@")) {
            this.email = emailOrName;
            this.name = "";
        } else {
            this.name = emailOrName;
        }
        this.password = password;
    }

    public UserInfo(String name, String password, String phone) {
        this.name = name;
        this.password = password;
        this.phone = phone;
    }
}
