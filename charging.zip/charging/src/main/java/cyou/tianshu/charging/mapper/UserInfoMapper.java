package cyou.tianshu.charging.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import cyou.tianshu.charging.entity.UserInfo;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface UserInfoMapper extends BaseMapper<UserInfo> {

    @Select("SELECT * FROM smart_charging_user WHERE id = #{userId}")
    List<UserInfo> findByUserId(@Param("userId") Long userId);

    @Select("SELECT * FROM smart_charging_user WHERE email = #{email} LIMIT 1")
    UserInfo findByEmail(@Param("email") String email);

    @Select("SELECT * FROM smart_charging_user WHERE phone = #{phone} LIMIT 1")
    UserInfo findByPhone(@Param("phone") String phone);

    @Select("SELECT COUNT(1) FROM smart_charging_user WHERE email = #{email}")
    Integer countByEmail(@Param("email") String email);

    @Select("SELECT COUNT(1) FROM smart_charging_user WHERE phone = #{phone}")
    Integer countByPhone(@Param("phone") String phone);

    @Insert("""
            INSERT INTO smart_charging_user (email, password, phone, name, role)
            VALUES (#{email}, #{password}, #{phone}, #{name}, #{role})
            """)
    void save(UserInfo userInfo);
}
