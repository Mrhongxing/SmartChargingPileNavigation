package cyou.tianshu.charging.util;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import cyou.tianshu.charging.entity.UserInfo;

import java.time.Instant;
import java.util.Date;

/**
 * 极简 JWT 工具：
 * - HS256 签名
 * - 过期时间可配置（app.jwt.expires-seconds）
 * - secret 必须用环境变量 JWT_SECRET 覆盖（不要用默认值）
 */
@Component
public class JwtUtil {

    private final Algorithm algorithm;
    private final JWTVerifier verifier;
    private final long expiresSeconds;

    public JwtUtil(
            @Value("${app.jwt.secret}") String secret,
            @Value("${app.jwt.expires-seconds:604800}") long expiresSeconds
    ) {
        this.algorithm = Algorithm.HMAC256(secret);
        this.verifier = JWT.require(this.algorithm).build();
        this.expiresSeconds = expiresSeconds;
    }

    public String generateToken(UserInfo user) {
        Instant now = Instant.now();
        Instant exp = now.plusSeconds(expiresSeconds);

        String subject = "";
        if (user.getId() != null) subject = String.valueOf(user.getId());
        else if (user.getEmail() != null && !user.getEmail().isBlank()) subject = user.getEmail();
        else if (user.getPhone() != null && !user.getPhone().isBlank()) subject = user.getPhone();

        return JWT.create()
                .withSubject(subject)
                .withIssuedAt(Date.from(now))
                .withExpiresAt(Date.from(exp))
                .withClaim("role", safe(user.getRole()))
                .withClaim("name", safe(user.getName()))
                .withClaim("email", safe(user.getEmail()))
                .withClaim("phone", safe(user.getPhone()))
                .sign(algorithm);
    }

    public DecodedJWT verify(String token) {
        return verifier.verify(token);
    }

    private String safe(String s) {
        return s == null ? "" : s;
    }
}
