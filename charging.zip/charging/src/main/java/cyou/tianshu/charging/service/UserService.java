package cyou.tianshu.charging.service;

import cyou.tianshu.charging.dto.LoginResponse;
import cyou.tianshu.charging.dto.RegisterResponse;
import cyou.tianshu.charging.entity.UserInfo;
import cyou.tianshu.charging.mapper.UserInfoMapper;
import cyou.tianshu.charging.util.JwtUtil;
import cyou.tianshu.charging.util.PasswordUtil;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Resource
    private PasswordUtil passwordUtil;

    @Resource
    private JwtUtil jwtUtil;

    @Resource
    private UserInfoMapper userInfoMapper;

    public LoginResponse loginByEmail(String email, String password) {
        UserInfo userInfo = userInfoMapper.findByEmail(email);
        return doLogin(userInfo, password);
    }

    public LoginResponse loginByPhone(String phone, String password) {
        UserInfo userInfo = userInfoMapper.findByPhone(phone);
        return doLogin(userInfo, password);
    }

    private LoginResponse doLogin(UserInfo userInfo, String password) {
        if (userInfo == null) {
            return emptyLogin();
        }
        boolean passwordMatches = passwordUtil.matches(password, userInfo.getPassword());
        if (!passwordMatches) {
            return emptyLogin();
        }
        String token = jwtUtil.generateToken(userInfo);
        return new LoginResponse(
                token,
                n(userInfo.getName()),
                n(userInfo.getEmail()),
                n(userInfo.getPhone()),
                n(userInfo.getCarType()),
                n(userInfo.getCarBrand()),
                n(userInfo.getRole())
        );
    }

    public RegisterResponse registerUser(String username, String password) {
        if (username == null || username.isBlank() || password == null || password.isBlank()) {
            return new RegisterResponse(false, "username/password required");
        }

        String encoded = passwordUtil.encodePassword(password);

        if (username.contains("@")) {
            // Register by email
            Integer c = userInfoMapper.countByEmail(username);
            if (c != null && c > 0) {
                return new RegisterResponse(false, "Email already registered");
            }
            UserInfo newUser = new UserInfo(username, encoded);
            newUser.setRole("user");
            userInfoMapper.save(newUser);
            return new RegisterResponse(true, "User registered successfully");
        } else {
            // Register by phone
            Integer c = userInfoMapper.countByPhone(username);
            if (c != null && c > 0) {
                return new RegisterResponse(false, "Phone number already registered");
            }
            UserInfo newUser = new UserInfo("", encoded, username);
            newUser.setRole("user");
            userInfoMapper.save(newUser);
            return new RegisterResponse(true, "User registered successfully");
        }
    }

    private LoginResponse emptyLogin() {
        return new LoginResponse("", "", "", "", "", "", "");
    }

    private String n(String s) {
        return s == null ? "" : s;
    }
}
