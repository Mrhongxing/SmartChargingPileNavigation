package cyou.tianshu.charging.controller;

import cyou.tianshu.charging.dto.LoginRequest;
import cyou.tianshu.charging.dto.LoginResponse;
import cyou.tianshu.charging.dto.RegisterResponse;
import cyou.tianshu.charging.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/apiForChargingStation/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest loginRequest) {
        if (loginRequest == null || loginRequest.getUsername() == null || loginRequest.getPassword() == null) {
            return ResponseEntity.status(400).body(new LoginResponse("", "", "", "", "", "", ""));
        }

        LoginResponse response;
        if (loginRequest.getUsername().contains("@")) {
            response = userService.loginByEmail(loginRequest.getUsername(), loginRequest.getPassword());
        } else {
            response = userService.loginByPhone(loginRequest.getUsername(), loginRequest.getPassword());
        }

        if (response != null && response.getToken() != null && !response.getToken().isEmpty()) {
            return ResponseEntity.ok(response);
        }
        return ResponseEntity.status(401).body(response == null ? new LoginResponse("", "", "", "", "", "", "") : response);
    }

    @PostMapping("/register")
    public ResponseEntity<RegisterResponse> register(@RequestBody LoginRequest registerRequest) {
        try {
            RegisterResponse response = userService.registerUser(registerRequest.getUsername(), registerRequest.getPassword());
            if (!response.isSuccess()) {
                return ResponseEntity.status(400).body(response);
            }
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(new RegisterResponse(false, e.toString()));
        }
    }
}
